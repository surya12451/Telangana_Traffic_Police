/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telangana_traffic_police;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Admin
 */
public class namefinder extends javax.swing.JFrame {
    public static String z;
    
    public static String a;
    public namefinder(){
        
    }
    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) { 
        
    }
    
    
    void sql(){
         try{
    Class.forName("java.sql.DriverManager");
    Connection y=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/details","root","neeraj");
    Statement s=y.createStatement();
    String query="select name from deatils where username='"+a+"';";
    
    ResultSet x=s.executeQuery(query);
    
    
    if(x.next()){
        String name=x.getString("name");
        
        
        
       main main1=new main();
       String name1=main1.getName();
    
     
        
        
        
        
    }else{
        
        
    }
    }
         catch(Exception z)
{
    JOptionPane.showMessageDialog(null,z);
}
    }
}
//put jTextField1's value in the array.

    


